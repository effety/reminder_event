<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-xl-6">
    <div class="d-flex align-items-center justify-content-between">
        <div>
            <?php
            $admin = auth()->user();
            $user = $admin->user;
            $activeCall = App\Models\Chat::where(function ($query) use ($user) {
                $query->where('receiver_id', $user->id)
                      ->orWhere('caller_id', $user->id);
            })
            ->whereIn('status', ['active', 'pending'])
            ->first();
            ?>

            <?php if($activeCall): ?>
                <a id="endCallbutton" class="btn btn-sm btn-danger ml-2"><?php echo e(translate('End Call')); ?></a>
            <?php else: ?>
                <p><?php echo e(translate('No active call')); ?></p>
            <?php endif; ?>
        </div>
        <!-- <div class="ml-2">
            <input type="text" class="form-control" id="searchByUsername" placeholder="Search By Username">
        </div> -->
    </div>
</div>

    <div class="col-xl-6">
        <div class="card card-plain">
            
            <form id="searchForm">
            <div class="d-flex" style="margin-right: 20px;">
    <div class="filter-select-box">
        <select name="country">
            <option value=""><?php echo e(translate('Select Country')); ?></option>
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="filter-select-box">
        <select name="language">
        <option value=""><?php echo e(translate('Select Language')); ?></option>
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($language->id); ?>"><?php echo e($language->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="filter-select-box">
        <select name="age">
        <option value=""><?php echo e(translate('Select Age')); ?></option>
                        <option value="18-25">18-25</option>
                        <option value="26-35">26-35</option>
                        <option value="36-45">36-45</option>
                        <option value="46-55">46-55</option>
                        <option value="56-65">56-65</option>
                        <option value="66-75">66-75</option>
                        <option value="76 and more">76 and more</option>
                 </select>       
                </div>
                    <div class="filter-select-box">
                        <select name="gender">
                        <option value=""><?php echo e(translate('Select Gender')); ?></option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="others">Others</option>
                        </select>
                    </div>
                    </div>
                    </form>
                    
        </div>
</div>
<div class="row">
<div id="bannerSlider" class="carousel slide" data-ride="carousel" style="margin-right: 50px;">
  <div class="carousel-inner">
    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
      <img src="<?php echo e(asset('images/apps/'.$slider->image)); ?>" class="d-block w-100" alt="<?php echo e($slider->banner_name); ?>" height="300px">
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <a class="carousel-control-prev" href="#bannerSlider" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only"><?php echo e(translate('Previous')); ?></span>
  </a>
  <a class="carousel-control-next" href="#bannerSlider" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only"><?php echo e(translate('Next')); ?></span>
  </a>
</div>

</div>
<div id="userDetails"></div>

<div id="searchFriends" class="row"></div>
<a id="loadMore" href="#" class="d-none text-primary"><?php echo e(translate('See More')); ?></a>

<div class="row" id="randomUsers">
<h5 class="text-primary"><?php echo e(translate('Pals')); ?></h5>
<?php if(isset($message)): ?>
    <div class="alert alert-info"><?php echo e($message); ?></div>
    <?php else: ?>
    <?php
    $backgroundColors = ['bg-custom1', 'bg-custom2', 'bg-custom3'];
    $colorIndex = 0;
?>
<?php $__currentLoopData = $randomusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        // Get the current background color
        $currentColor = $backgroundColors[$colorIndex % count($backgroundColors)];
        // Define the border color based on the background color
        $borderColor = $currentColor;
    ?>
    <div class="col-lg-2 col-md-4 col-sm-6 mt-4 mb-4">
        <div class="card shadow d-flex flex-column justify-content-between align-items-center custom-border border-<?php echo e($borderColor); ?>" style="height: 200px; border-radius: 10px !important;">
            <div class="position-relative w-100 h-100" style="overflow: hidden;">
                <div class="position-absolute top-0 start-0 w-100 h-30 <?php echo e($currentColor); ?>"></div>
                <div class="position-absolute bottom-0 start-0 w-100 h-70 bg-white"></div>
                <div class="position-absolute top-50 start-50 translate-middle text-center" style="z-index: 1;">
                    <img src="<?php echo e($ruser->profile_pic ? asset('images/users/' . $ruser->profile_pic) : asset('images/users/avatar.jpg')); ?>" class="rounded-circle" height="70px" width="70px" style="position: relative; z-index: 2;">
                    <p class="card-title mt-2" style="position: relative; z-index: 2; white-space: nowrap;"><?php echo e($ruser->first_name); ?> <?php echo e($ruser->last_name); ?></p>
                </div>
            </div>
            <div class="text-center mb-2">
                <a href="<?php echo e(route('match.details', ['userId' => encrypt($ruser->id)])); ?>" class="btn btn-sm btn-primary"><?php echo e(translate('Invite')); ?></a>
            </div>
        </div>
    </div>
    <?php
        $colorIndex++;
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







<?php endif; ?>


</div>
<script>
    // Your script here
    function subscribeAlert() {
        toastr.error('Please subscribe to access this feature.');
    }
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
   let currentPage = 1;
    let colorIndex = 0;
    const backgroundColors = ['bg-custom1', 'bg-custom2', 'bg-custom3']; 

function loadUsers(page) {
    $('#randomUsers').hide();
    var formData = $('#searchForm').serialize() + '&page=' + page;
    $.ajax({
        url: "<?php echo e(route('search')); ?>",
        method: "GET",
        data: formData,
        dataType: "json",
        success: function(response) {
            if (page === 1) {
                $('#searchFriends').empty();
            }

            $.each(response.data, function(index, user) {
                let currentColor = backgroundColors[colorIndex % backgroundColors.length];
                let borderColor = currentColor;
                colorIndex++;

                let userHtml = `
                    <div class="col-lg-2 col-md-4 col-sm-6 mt-4 mb-4">
                        <div class="card shadow d-flex flex-column justify-content-between align-items-center custom-border border-${borderColor}" style="height: 200px; border-radius: 10px !important;">
                            <div class="position-relative w-100 h-100" style="overflow: hidden;">
                                <div class="position-absolute top-0 start-0 w-100 h-30 ${currentColor}"></div>
                                <div class="position-absolute bottom-0 start-0 w-100 h-70 bg-white"></div>
                                <div class="position-absolute top-50 start-50 translate-middle text-center" style="z-index: 1;">
                                    <img src="${user.profile_pic ? 'images/users/' + user.profile_pic : '<?php echo e(asset('images/users/avatar.jpg')); ?>'}" class="rounded-circle" height="70px" width="70px" style="position: relative; z-index: 2;">
                                    <p class="card-title mt-2" style="position: relative; z-index: 2; white-space: nowrap;">${user.first_name} ${user.last_name}</p>
                                </div>
                            </div>
                            <div class="text-center mb-2">
                            <a href="<?php echo e(route('match.details', ['userId' => encrypt($ruser->id)])); ?>" class="btn btn-sm btn-primary"><?php echo e(translate('Invite')); ?></a>
                            </div>
                        </div>
                    </div>`;
                    
                $('#searchFriends').append(userHtml);
            });

            if (response.next_page_url) {
                $('#loadMore').removeClass('d-none');
            } else {
                $('#loadMore').addClass('d-none');
            }
        },
        error: function(xhr, status, error) {
            console.error(error);
        }
    });
}

$('#searchForm select, #searchForm input[type="date"]').change(function() {
    currentPage = 1;
    loadUsers(currentPage);
});

$('#loadMore').click(function(e) {
    e.preventDefault();
    currentPage++;
    loadUsers(currentPage);
});



    $('#searchByUsername').on('keyup', function() {
    var username = $(this).val();
    console.log(username); // Log the username for debugging

    $.ajax({
        url: '<?php echo e(route("searchByUsername")); ?>',
        method: 'POST',
        data: { username: username },
        dataType: 'json',
        success: function(response) {
            if (response.user) {
                var user = response.user; // Corrected variable name
                var userDetails = '<div class="col-lg-2 col-md-4 col-sm-6 mt-4 mb-4">' +
                    '<div class="card bg-transparent shadow-xl d-flex justify-content-center align-items-center" style="height: 200px;">' +
                    '<div class="overflow-hidden position-relative border-radius-xl text-center">';
                if (user.profile_pic) {
                    userDetails += '<img src="images/users/' + user.profile_pic + '" height="100px" width="100px">';
                } else {
                    userDetails += '<img src="<?php echo e(asset('images/users/avatar.jpg')); ?>" height="100px" width="100px">';
                }
                userDetails += '<p class="card-title mt-2">' + user.first_name + ' ' + user.last_name + '</p>';

                // Check if the logged-in user is subscribed or not
                userDetails += '<a href="<?php echo e(route('match.details', ['userId' => encrypt($ruser->id)])); ?>" class="btn btn-sm btn-primary"><?php echo e(translate('Invite')); ?></a>';

                userDetails += '</div>' +
                    '</div>' +
                    '</div>';

                // Append the generated HTML to the userDetails div
                $('#userDetails').html(userDetails);
            } else {
                $('#userDetails').html('<p><?php echo e(translate('User not found')); ?></p>');
            }
        },
        error: function(xhr, status, error) {
            console.error(error);
        }
    });
});

});
    

$('#endCallbutton').click(function(e) {
    e.preventDefault();
    $.ajax({
        url: '<?php echo e(route("reject.call")); ?>',
        type: 'POST',
        data: {
            _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function(response) {
            if (response.success) {
                window.location.href = '<?php echo e(route("dashboard")); ?>';
            } else {
            }
        },
        error: function(xhr, status, error) {
            console.error(error);
        }
    });
        });
    </script>
    <script>
  $(document).ready(function() {
    $('#bannerSlider').carousel();
    $('#bannerSlider').carousel({
      interval: 300
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web-poll\resources\views\dashboard.blade.php ENDPATH**/ ?>