

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Polls</h2>
        <a href="<?php echo e(route('polls.create')); ?>" class="btn btn-success mb-3">Create Poll</a>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Private</th>
                    <th>Status</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $polls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($poll->title); ?></td>
                        <td><?php echo e($poll->is_private ? 'Private' : 'Public'); ?></td>
                        <td><?php echo e($poll->status); ?></td>
                        <td><?php echo e($poll->start_time); ?></td>
                        <td><?php echo e($poll->end_time); ?></td>
                        <td>
                          <a href="<?php echo e(route('showPollDetails', $poll->id)); ?>" class="btn btn-primary">Share Link</a>
                            <a href="<?php echo e(route('polls.edit', $poll->id)); ?>" class="btn btn-primary">Edit</a>
                            <form action="<?php echo e(route('polls.destroy', $poll->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                            <button class="btn btn-info show-options">Show Options</button>
                        </td>
                    </tr>
                    <tr class="options-row" style="display: none;">
                        <td colspan="6">
                            <ul>
                                <?php $__currentLoopData = $poll->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($option->option); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('.show-options').click(function () {
                $(this).closest('tr').next('.options-row').toggle();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web-poll\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>