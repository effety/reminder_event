<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="icon" type="image/x-icon" href="<?php echo e(asset('images/apps/favicon.ico')); ?>">
  <title>
    Poll
  </title>
<!-- Fonts and icons -->
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
<!-- Nucleo Icons -->
<link href="<?php echo e(asset('assets/css/nucleo-icons.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
<!-- Font Awesome Icons -->
<script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
<!-- Material Icons -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
<!-- CSS Files -->
<link id="pagestyle" href="<?php echo e(asset('assets/css/material-dashboard.css?v=3.0.4')); ?>" rel="stylesheet" />

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">

<!-- Include jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  
</head>
<style>
    .background-image {
        background-image: url('<?php echo e(asset("images/apps/loginbg.jpg")); ?>');
        background-size: cover; /* Cover the entire background */
        background-position: center; /* Center the background image */
    }
</style>

<body class="bg-gray-200">
<section>

    </section>
  <!--   Core JS Files   -->
  <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins/smooth-scrollbar.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>




</body>

</html><?php /**PATH C:\xampp\htdocs\web-poll\resources\views\register.blade.php ENDPATH**/ ?>