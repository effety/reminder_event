<?php $__env->startSection('content'); ?>
<style>
.upload-icon {
    position: absolute;
    bottom: 15px;
    right: 25px;
    background-color: white;
    border: 1px solid #ccc;
    border-radius: 50%;
    padding: 6px;
    font-size: 20px;
    color: #555;
    z-index: 3; 
    width: 30px;
    height: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
}


</style>
<div class="row">
<?php
    $currentColor = 'bg-custom2'; // Set the current color to pink
?>
<div class="col-lg-3 col-md-4 col-sm-6 mt-4 mb-4">
    <div class="card shadow d-flex flex-column justify-content-between align-items-center custom-border border-<?php echo e($currentColor); ?>" style="border-radius: 10px !important; position: relative;">
        <div class="position-relative w-100" style="height: 250px; overflow: hidden;">
            <div class="position-absolute top-0 start-0 w-100 h-30 <?php echo e($currentColor); ?>"></div>
            <div class="position-absolute bottom-0 start-0 w-100 h-70 bg-white"></div>
            <div class="position-absolute top-50 start-50 translate-middle text-center" style="z-index: 1;">
                <img src="<?php echo e(asset($user->profile_pic ? 'images/users/' . $user->profile_pic : 'images/users/avatar.jpg')); ?>" 
                     class="rounded-circle profile-image" 
                     height="200px" 
                     width="200px" 
                     style="position: relative; z-index: 2;">
                <label for="profilePicUpload" class="upload-icon">
                    <i class="fas fa-upload"></i>
                </label>
                <input type="file" id="profilePicUpload" name="profile_pic" style="display: none;">
            </div>
        </div>
        <div class="text-center mb-2">
            <h5 class="card-title"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h5>
        </div>
        <div class="text-center mb-3">
            <label for="additional_information"><?php echo e(translate('Bio')); ?></label>
            <p class="text-warning" style="font-size: 13px;"><?php echo e($user->about_me); ?></p>
        </div>
    </div>
</div>

<div class="col-lg-9 col-md-4 col-sm-9 mt-4 mb-4">
<form method="POST" action="<?php echo e(route('user.update')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-4 mb-3">
            <label for="first_name" class="mb-1"><?php echo e(translate('First Name')); ?></label>
            <input type="text" id="first_name" name="first_name" class="form-control" value="<?php echo e($user->first_name); ?>" required>
        </div>
        <div class="col-md-4 mb-3">
            <label for="last_name" class="mb-1"><?php echo e(translate('Last Name')); ?></label>
            <input type="text" id="last_name" name="last_name" class="form-control" value="<?php echo e($user->last_name); ?>" required>
        </div>
        <div class="col-md-4 mb-3">
            <label for="gender" class="mb-1"><?php echo e(translate('Gender')); ?></label>
            <select id="gender" name="gender" class="form-control">
                <option value="male" <?php echo e($user->gender === 'male' ? 'selected' : ''); ?>><?php echo e(translate('Male')); ?></option>
                <option value="female" <?php echo e($user->gender === 'female' ? 'selected' : ''); ?>><?php echo e(translate('Female')); ?></option>
                <option value="female" <?php echo e($user->gender === 'others' ? 'selected' : ''); ?>><?php echo e(translate('Others')); ?></option>
            </select>
        </div>
    </div>
    <div class="row" >
        <div class="col-md-4 mb-3">
            <label for="country" class="mb-1"><?php echo e(translate('Country')); ?></label>
            <select multiple id="js--country-multi-select"  name="country[]" data-placeholder="Add origin Countries" class="form-control">
        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($country->id); ?>" <?php echo e(in_array($country->id, explode(',', $user->country)) ? 'selected' : ''); ?>>
            <?php echo e($country->name); ?>

        </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
        </div>
        <div class="col-md-4 mb-3">
            <label for="language" class="mb-1"><?php echo e(translate('Language')); ?></label>
            <select multiple id="js--language-multi-select"  name="language[]" data-placeholder="Add Languages" class="form-control">

            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($language->id); ?>" <?php echo e(in_array($language->id, explode(',', $user->language)) ? 'selected' : ''); ?>>
            <?php echo e($language->name); ?>

        </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-4 mb-3">
            <label for="country" class="mb-1"><?php echo e(translate('City')); ?></label>
            <input type="text" id="address" name="city" class="form-control" value="<?php echo e($user->city); ?>" placeholder="Enter your city">
        </div>
    </div>
    <div class="row">
    <div class="col-md-4 mb-3">
            <label for="address" class="mb-1"><?php echo e(translate('Address')); ?></label>
            <input type="text" id="address" name="address" class="form-control" value="<?php echo e($user->address); ?>">
        </div>
        <div class="col-md-4 mb-3">
            <label for="postal_code" class="mb-1"><?php echo e(translate('Postal code')); ?></label>
            <input type="text" id="postal_code" name="postal_code" class="form-control" value="<?php echo e($user->postal_code); ?>">
        </div>
        <div class="col-md-4 mb-3">
            <label for="phone" class="mb-1"><?php echo e(translate('Date of Birth')); ?></label>
            <input type="text" id="age" name="age" class="form-control" value="<?php echo e(\Carbon\Carbon::parse($user->age)->format('d.m.Y')); ?>

">
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 mb-3">
            <label for="phone" class="mb-1"><?php echo e(translate('Phone')); ?></label>
            <input type="text" id="phone" name="phone" class="form-control" value="<?php echo e($user->phone); ?>">
        </div>

        <div class="col-md-4 mb-3">
        <label for="professional_situation"><?php echo e(translate('Professional Status')); ?></label>
        <select class="form-control" id="professional_situation" name="professional_situation">
            <option value="">Professional Status</option>
            <option value="student" <?php echo e($user->professional_situation == 'student' ? 'selected' : ''); ?>>Student</option>
            <option value="employee" <?php echo e($user->professional_situation == 'employee' ? 'selected' : ''); ?>>Employee</option>
            <option value="self-employed" <?php echo e($user->professional_situation == 'self-employed' ? 'selected' : ''); ?>>Self-Employed</option>
            <option value="unemployed" <?php echo e($user->professional_situation == 'unemployed' ? 'selected' : ''); ?>>Unemployed</option>
        </select>
    </div>
    <div class="col-md-4 mb-3">
            <label for="occupation"><?php echo e(translate('Occupation')); ?></label>
            <input type="text" class="form-control" id="occupation" name="occupation" value="<?php echo e($user->occupation); ?>">
        </div>
    </div>
    <div class="row">
    <div class="col-md-4 mb-3">
    <label for="education_level"><?php echo e(translate('Education Level Completed')); ?></label>
    <select class="form-control" id="education_level" name="education_level">
        <option value="">Select Education</option>
        <option value="high_school" <?php echo e($user->education_level == 'high_school' ? 'selected' : ''); ?>>High School</option>
        <option value="associate_degree" <?php echo e($user->education_level == 'associate_degree' ? 'selected' : ''); ?>>Associate's Degree</option>
        <option value="bachelor_degree" <?php echo e($user->education_level == 'bachelor_degree' ? 'selected' : ''); ?>>Bachelor's Degree</option>
        <option value="master_degree" <?php echo e($user->education_level == 'master_degree' ? 'selected' : ''); ?>>Master's Degree</option>
        <option value="doctorate" <?php echo e($user->education_level == 'doctorate' ? 'selected' : ''); ?>>Doctorate</option>
    </select>
</div>

<div class="col-md-4 mb-3">
    <label for="music_genre"><?php echo e(translate('Favorite Genre of Music')); ?></label>
    <select class="form-control" id="music_genre" name="music_genre">
        <option value="">Select Music</option>
        <option value="classic_music" <?php echo e($user->music_genre == 'Classic_music' ? 'selected' : ''); ?>>Classic music</option>
        <option value="electronic_music" <?php echo e($user->music_genre == 'electronic_music' ? 'selected' : ''); ?>>Electronic music</option>
        <option value="rock" <?php echo e($user->music_genre == 'rock' ? 'selected' : ''); ?>>Rock</option>
        <option value="pop" <?php echo e($user->music_genre == 'pop' ? 'selected' : ''); ?>>Pop</option>
        <option value="hip_hop" <?php echo e($user->music_genre == 'hip_hop' ? 'selected' : ''); ?>>Hip-Hop</option>
        <option value="jazz" <?php echo e($user->music_genre == 'jazz' ? 'selected' : ''); ?>>Jazz</option>
        <option value="reggae" <?php echo e($user->music_genre == 'reggae' ? 'selected' : ''); ?>>Reggae</option>
        <option value="world_music" <?php echo e($user->music_genre == 'world_music' ? 'selected' : ''); ?>>World music</option>
    </select>
</div>
            
<div class="col-md-4 mb-3">
    <label for="film_series_preference"><?php echo e(translate('Types of Films or Series You Usually Watch')); ?></label>
    <select class="form-control" id="film_series_preference" name="film_series_preference">
        <option value="animation" <?php echo e($user->film_series_preference == 'animation' ? 'selected' : ''); ?>>Animation</option>
        <option value="biopic" <?php echo e($user->film_series_preference == 'biopic' ? 'selected' : ''); ?>>Biopic</option>
        <option value="comedy" <?php echo e($user->film_series_preference == 'comedy' ? 'selected' : ''); ?>>Comedy</option>
        <option value="drama" <?php echo e($user->film_series_preference == 'drama' ? 'selected' : ''); ?>>Drama</option>
        <option value="thriller" <?php echo e($user->film_series_preference == 'thriller' ? 'selected' : ''); ?>>Thriller</option>
        <option value="documentary" <?php echo e($user->film_series_preference == 'documentary' ? 'selected' : ''); ?>>Documentary</option>
        <option value="fantastic" <?php echo e($user->film_series_preference == 'fantastic' ? 'selected' : ''); ?>>Fantastic/ science-fiction
</option>
        <option value="horror" <?php echo e($user->film_series_preference == 'horror' ? 'selected' : ''); ?>>Horror</option>
    </select>
</div>
    </div>
    <div class="row">

    <div class="col-md-4 mb-3">
    <label for="artistic_activities"><?php echo e(translate('Artistic Activities')); ?></label>
    <select class="form-control" id="artistic_activities" name="artistic_activities">
        <option value="music" <?php echo e($user->artistic_activities == 'music' ? 'selected' : ''); ?>>Music</option>
        <option value="painting" <?php echo e($user->artistic_activities == 'painting' ? 'selected' : ''); ?>>Painting</option>
        <option value="writing" <?php echo e($user->artistic_activities == 'writing' ? 'selected' : ''); ?>>Writing</option>
        <option value="photography" <?php echo e($user->artistic_activities == 'photography' ? 'selected' : ''); ?>>Photography</option>
    </select>
</div>

<div class="col-md-4 mb-3">
    <label for="sport_practiced"><?php echo e(translate('Type of Sport Practiced')); ?></label>
    <select class="form-control" id="sport_practiced" name="sports">
        <option value="football" <?php echo e($user->sports == 'football' ? 'selected' : ''); ?>>Football</option>
        <option value="basketball" <?php echo e($user->sports == 'basketball' ? 'selected' : ''); ?>>Basketball</option>
        <option value="tennis" <?php echo e($user->sports == 'tennis' ? 'selected' : ''); ?>>Tennis</option>
        <option value="swimming" <?php echo e($user->sports == 'swimming' ? 'selected' : ''); ?>>Swimming</option>
        <option value="archery" <?php echo e($user->sports == 'archery' ? 'selected' : ''); ?>>Archery</option>
        <option value="basket" <?php echo e($user->sports == 'basket' ? 'selected' : ''); ?>>Basket</option>
        <option value="bike" <?php echo e($user->sports == 'bike' ? 'selected' : ''); ?>>Bike</option>
        <option value="box" <?php echo e($user->sports == 'box' ? 'selected' : ''); ?>>Box</option>
        <option value="dance" <?php echo e($user->sports == 'dance' ? 'selected' : ''); ?>>Dance</option>
        <option value="escalation" <?php echo e($user->sports == 'escalation' ? 'selected' : ''); ?>>Escalation</option>
        <option value="golf" <?php echo e($user->sports == 'golf' ? 'selected' : ''); ?>>Golf</option>
        <option value="hiking" <?php echo e($user->sports == 'hiking' ? 'selected' : ''); ?>>Hiking</option>
        <option value="horse riding" <?php echo e($user->sports == 'horse riding' ? 'selected' : ''); ?>>Horse riding</option>
        <option value="jogging" <?php echo e($user->sports == 'jogging' ? 'selected' : ''); ?>>Jogging</option>
        <option value="musculature" <?php echo e($user->sports == 'musculature' ? 'selected' : ''); ?>>Musculature</option>
        <option value="nation" <?php echo e($user->sports == 'nation' ? 'selected' : ''); ?>>Nation</option>
        <option value="petanque" <?php echo e($user->sports == 'petanque' ? 'selected' : ''); ?>>Petanque</option>
        <option value="ping pong" <?php echo e($user->sports == 'ping pong' ? 'selected' : ''); ?>>Ping pong</option>
        <option value="ski" <?php echo e($user->sports == 'ski' ? 'selected' : ''); ?>>Ski</option>
        <option value="soccer" <?php echo e($user->sports == 'soccer' ? 'selected' : ''); ?>>Soccer</option>
        <option value="squash" <?php echo e($user->sports == 'squash' ? 'selected' : ''); ?>>Squash</option>
        <option value="tennis" <?php echo e($user->sports == 'tennis' ? 'selected' : ''); ?>>Tennis</option>
        <option value="veil" <?php echo e($user->sports == 'veil' ? 'selected' : ''); ?>>Veil</option>
        <option value="volleyball" <?php echo e($user->sports == 'volleyball' ? 'selected' : ''); ?>>Volleyball</option>
        <option value="yoga" <?php echo e($user->sports == 'yoga' ? 'selected' : ''); ?>>Yoga</option>
    </select>
</div>


<div class="col-md-4 mb-3">
    <label for="marital_status"><?php echo e(translate('Relationship Status')); ?></label>
    <select class="form-control" id="relationship_status" name="relationship_status">
        <option value="single" <?php echo e($user->relationship_status == 'single' ? 'selected' : ''); ?>>Single</option>
        <option value="in_relationship" <?php echo e($user->relationship_status == 'in_relationship' ? 'selected' : ''); ?>>In a Relationship</option>
        <option value="married" <?php echo e($user->relationship_status == 'married' ? 'selected' : ''); ?>>Married</option>
        <option value="divorced" <?php echo e($user->relationship_status == 'divorced' ? 'selected' : ''); ?>>Divorced</option>
        <option value="widowed" <?php echo e($user->relationship_status == 'widowed' ? 'selected' : ''); ?>>Widowed</option>
    </select>
</div>
    </div>
    <div class="row">

    <div class="col-md-4 mb-3">
    <label for="children"><?php echo e(translate('Do you have children?')); ?></label>
    <select class="form-control" id="children" name="children">
        <option value="yes" <?php echo e($user->children == 'yes' ? 'selected' : ''); ?>>Yes</option>
        <option value="no" <?php echo e($user->children == 'no' ? 'selected' : ''); ?>>No</option>
    </select>
</div>

<div class="col-md-4 mb-3">
    <label for="number_of_children"><?php echo e(translate('If yes, how many children?')); ?></label>
    <select class="form-control" id="number_of_children" name="number_of_children">
        <option value=""><?php echo e(translate('Select number of children')); ?></option>
        <?php for($i = 1; $i <= 10; $i++): ?>
            <option value="<?php echo e($i); ?>" <?php echo e($user->number_of_children == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
        <?php endfor; ?>
    </select>
</div>
<div class="col-md-4 mb-3">
    <label for="religious_affiliation"><?php echo e(translate('Religious or Spiritual Affiliation')); ?></label>
    <select class="form-control" id="religious_affiliation" name="religious_affiliation">
        <option value="yes" <?php echo e($user->religious_affiliation == 'yes' ? 'selected' : ''); ?>>Yes</option>
        <option value="no" <?php echo e($user->religious_affiliation == 'no' ? 'selected' : ''); ?>>No</option>
    </select>
</div>
    </div>
    <div class="row">

    <div class="col-md-4 mb-3">
    <label for="religious_affiliation"><?php echo e(translate('Religions')); ?></label>
    <select class="form-control" id="religious_affiliation" name="religion_name">
        <option value="buddhism" <?php echo e($user->religion_name == 'buddhism' ? 'selected' : ''); ?>>Buddhism</option>
        <option value="christianity" <?php echo e($user->religion_name == 'christianity' ? 'selected' : ''); ?>>Christianity</option>
        <option value="hinduism" <?php echo e($user->religion_name == 'hinduism' ? 'selected' : ''); ?>>Hinduism</option>
        <option value="islam" <?php echo e($user->religion_name == 'islam' ? 'selected' : ''); ?>>Islam</option>
        <option value="judaism" <?php echo e($user->religion_name == 'judaism' ? 'selected' : ''); ?>>Judaism</option>
        <option value="other" <?php echo e($user->religion_name == 'other' ? 'selected' : ''); ?>>Other</option>
    </select>
</div>
      <div class="col-md-4 mb-3">
      <label for="additional_information"><?php echo e(translate('Write About yoruself (Max 500)')); ?></label>
      <textarea class="form-control" id="additional_information" name="about_me" placeholder="Additional Information (500 characters max)" rows="3" maxlength="500"><?php echo e($user->about_me); ?></textarea>

        </div>
        </div>
    <button type="submit" class="btn btn-primary"><?php echo e(translate('Update Profile')); ?></button>
</form>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="assets/js/select2.full.min.js"> </script>
<script>
 $(document).ready(function() {
        $('#js--country-multi-select').select2({
            maximumSelectionLength: 4 
        });
        $('#js--city-multi-select').select2({
            maximumSelectionLength: 1 
        });
        $('#js--language-multi-select').select2({
            maximumSelectionLength: 10 
        });


    $('#profilePicUpload').on('change', function() {
        var file = this.files[0];
        if (file) {
            uploadProfilePic(file);
        }
    });
    function uploadProfilePic(file) {
        var formData = new FormData();
        formData.append('profile_pic', file);

        $.ajax({
            url: '<?php echo e(route('upload.profile.pic')); ?>',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                if (response.success) {
                    $('.profile-image').attr('src', response.profile_pic_url);
                    // alert('Profile picture updated successfully!');
                } else {
                    alert('Failed to update profile picture.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
                // alert('An error occurred while uploading the profile picture.');
            }
        });
    }
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web-poll\resources\views\profile.blade.php ENDPATH**/ ?>