

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Edit Poll</h2>

        <form action="<?php echo e(route('polls.update', $poll->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="title">Poll Title</label>
                <input type="text" name="title" class="form-control" value="<?php echo e($poll->title); ?>" required>
            </div>

            <div class="form-group">
                <label for="is_private">Poll Privacy</label>
                <select name="is_private" class="form-control">
                    <option value="0" <?php echo e($poll->is_private == 0 ? 'selected' : ''); ?>>Public</option>
                    <option value="1" <?php echo e($poll->is_private == 1 ? 'selected' : ''); ?>>Private</option>
                </select>
            </div>

            <div class="form-group">
                <label for="start_time">Start Time</label>
                <input type="datetime-local" name="start_time" class="form-control" value="<?php echo e($poll->start_time); ?>">
            </div>

            <div class="form-group">
                <label for="end_time">End Time</label>
                <input type="datetime-local" name="end_time" class="form-control" value="<?php echo e($poll->end_time); ?>">
            </div>

            <div class="form-group">
                <label>Poll Options</label>
                <table class="table" id="poll-options">
                    <?php $__currentLoopData = $poll->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><input type="text" name="options[]" class="form-control" value="<?php echo e($option->option); ?>" required></td>
                            <td><button type="button" class="btn btn-danger remove-row">Remove</button></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <button type="button" class="btn btn-success add-row">Add Option</button>
            </div>

            <button type="submit" class="btn btn-primary">Update Poll</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('.add-row').click(function () {
                $('#poll-options').append('<tr><td><input type="text" name="options[]" class="form-control"></td><td><button type="button" class="btn btn-danger remove-row">Remove</button></td></tr>');
            });

            $(document).on('click', '.remove-row', function () {
                $(this).closest('tr').remove();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web-poll\resources\views\admin\poll\edit.blade.php ENDPATH**/ ?>