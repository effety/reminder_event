

<?php $__env->startSection('content'); ?>
<!-- index.blade.php -->
<div class="row">
    <div align="right"><a class="btn btn-sm btn-info" href="<?php echo e(route('addTranslation')); ?>">Add Translations</a></div>
<div class="container">

    <table id="languageTable" class="display" style="width:100%">
    <thead>
        <tr>
            <th>SL</th>
            <th>Languages</th>
            <th>Language Code</th>
            <th>Translation Status</th>
        </tr>
    </thead>
    <tbody>
    <?php $i = 1; ?>
    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
        <tr>
            <td style="white-space: pre-wrap;"><?php echo e($i++); ?></td>
            <td style="white-space: pre-wrap;"><?php echo e($language->name); ?></td>
            <td style="white-space: pre-wrap;"><?php echo e($language->code); ?></td>
            <td>
                <form action="<?php echo e(route('updateTranslationStatus', $language->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="checkbox" name="transStatus" <?php echo e($language->translation_status ? 'checked' : ''); ?> onchange="this.form.submit()">
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
    $('#languageTable').DataTable({
        "paging": true, // Enable pagination
        "searching": true // Enable search functionality
    });
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web-poll\resources\views\admin\languages.blade.php ENDPATH**/ ?>