

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Employee Management</h2>
    
    <!-- Success Message -->
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-info text-white">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <!-- Add Employee Button -->
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addEmployeeModal">
        Add Employee
    </button>

    <!-- Employee Table -->
<table class="table table-bordered mt-3">
    <thead>
        <tr>
            <th>Name</th>
            <th>Address</th>
            <th>Photo</th>
            <th>Designation</th>
            <th>Phone</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($employee->name); ?></td>
                <td><?php echo e($employee->address); ?></td>
                <td><img src="<?php echo e(asset($employee->photo)); ?>" alt="Employee Photo" style="max-width: 100px; max-height: 100px;"></td>
                <td><?php echo e($employee->designation); ?></td>
                <td><?php echo e($employee->phone); ?></td>
                <td>
                    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#showEmployeeModal<?php echo e($employee->id); ?>">
                        Show
                    </button>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editEmployeeModal<?php echo e($employee->id); ?>">
                        Edit
                    </button>
                    <form action="<?php echo e(route('employees.destroy', $employee->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
<!-- Edit Modal -->
<div class="modal fade" id="editEmployeeModal<?php echo e($employee->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editEmployeeModal<?php echo e($employee->id); ?>Label" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(route('employees.update', $employee->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="editEmployeeModal<?php echo e($employee->id); ?>Label">Edit Employee</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Existing fields -->
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($employee->name); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="gender">Gender</label>
                        <select class="form-control" id="gender" name="gender" required>
                            <option value="Male" <?php echo e($employee->gender == 'Male' ? 'selected' : ''); ?>>Male</option>
                            <option value="Female" <?php echo e($employee->gender == 'Female' ? 'selected' : ''); ?>>Female</option>
                            <option value="Other" <?php echo e($employee->gender == 'Other' ? 'selected' : ''); ?>>Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="birthday">Birthday</label>
                        <input type="date" class="form-control" id="birthday" name="birthday" value="<?php echo e($employee->birthday); ?>">
                    </div>
                    <div class="form-group">
                        <label for="nid">NID</label>
                        <input type="text" class="form-control" id="nid" name="nid" value="<?php echo e($employee->nid); ?>">
                    </div>
                    <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" id="address" name="address" value="<?php echo e($employee->address); ?>">
                    </div>
                    <div class="form-group">
                        <label for="photo">Photo</label>
                        <input type="file" class="form-control-file" id="photo" name="photo">
                        <?php if($employee->photo): ?>
                            <img src="<?php echo e(asset($employee->photo)); ?>" alt="Employee Photo" class="img-fluid mt-2" style="max-width: 200px;">
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="branch_id">Branch</label>
                        <select class="form-control" id="branch_id" name="branch_id">
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch->id); ?>" <?php echo e($employee->branch_id == $branch->id ? 'selected' : ''); ?>><?php echo e($branch->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="designation">Designation</label>
                        <input type="text" class="form-control" id="designation" name="designation" value="<?php echo e($employee->designation); ?>">
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($employee->phone); ?>">
                    </div>
                    <div class="form-group">
                        <label for="salary">Salary</label>
                        <input type="number" class="form-control" id="salary" name="salary" step="0.01" value="<?php echo e($employee->salary); ?>">
                    </div>
                    <div class="form-group">
                        <label for="eSalaryAcc">eSalaryAcc</label>
                        <input type="text" class="form-control" id="eSalaryAcc" name="eSalaryAcc" value="<?php echo e($employee->eSalaryAcc); ?>">
                    </div>
                    <div class="form-group">
                        <label for="payLeave">Pay Leave</label>
                        <input type="number" class="form-control" id="payLeave" name="payLeave" value="<?php echo e($employee->payLeave); ?>">
                    </div>
                    <div class="form-group">
                        <label for="npayLeave">Non-Pay Leave</label>
                        <input type="number" class="form-control" id="npayLeave" name="npayLeave" value="<?php echo e($employee->npayLeave); ?>">
                    </div>
                    <div class="form-group">
                        <label for="evmoSalarydate">Salary Date</label>
                        <input type="date" class="form-control" id="evmoSalarydate" name="evmoSalarydate" value="<?php echo e($employee->evmoSalarydate); ?>">
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select class="form-control" id="status" name="status">
                            <option value="Active" <?php echo e($employee->status == 'Active' ? 'selected' : ''); ?>>Active</option>
                            <option value="Inactive" <?php echo e($employee->status == 'Inactive' ? 'selected' : ''); ?>>Inactive</option>
                            <option value="On Leave" <?php echo e($employee->status == 'On Leave' ? 'selected' : ''); ?>>On Leave</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="joinDate">Join Date</label>
                        <input type="date" class="form-control" id="joinDate" name="joinDate" value="<?php echo e($employee->joinDate); ?>">
                    </div>
                    <div class="form-group">
                        <label for="joinTime">Join Time</label>
                        <input type="time" class="form-control" id="joinTime" name="joinTime" value="<?php echo e($employee->joinTime); ?>">
                    </div>
                    <div class="form-group">
                        <label for="author">Author</label>
                        <input type="text" class="form-control" id="author" name="author" value="<?php echo e($employee->author); ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

            <!-- Show Employee Modal -->
            <div class="modal fade" id="showEmployeeModal<?php echo e($employee->id); ?>" tabindex="-1" role="dialog" aria-labelledby="showEmployeeModalLabel<?php echo e($employee->id); ?>" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="showEmployeeModalLabel<?php echo e($employee->id); ?>">Employee Details</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                        <p><strong>Photo:</strong> <img src="<?php echo e(asset($employee->photo)); ?>" alt="Employee Photo" style="max-width: 100px; max-height: 100px;"></p>
                            <p><strong>Name:</strong> <?php echo e($employee->name); ?></p>
                            <p><strong>Gender:</strong> <?php echo e($employee->gender); ?></p>
                            <p><strong>Birthday:</strong> <?php echo e($employee->birthday); ?></p>
                            <p><strong>NID:</strong> <?php echo e($employee->nid); ?></p>
                            <p><strong>Address:</strong> <?php echo e($employee->address); ?></p>
                            
                            <p><strong>Branch ID:</strong> <?php echo e(optional($employee->branch)->name); ?></p>
                            <p><strong>Designation:</strong> <?php echo e($employee->designation); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($employee->phone); ?></p>
                            <p><strong>Salary:</strong> <?php echo e($employee->salary); ?></p>
                            <p><strong>eSalaryAcc:</strong> <?php echo e($employee->eSalaryAcc); ?></p>
                            <p><strong>Pay Leave:</strong> <?php echo e($employee->payLeave); ?></p>
                            <p><strong>Non-Pay Leave:</strong> <?php echo e($employee->npayLeave); ?></p>
                            <p><strong>Salary Date:</strong> <?php echo e($employee->evmoSalarydate); ?></p>
                            <p><strong>Status:</strong> <?php echo e($employee->status); ?></p>
                            <p><strong>Join Date:</strong> <?php echo e($employee->joinDate); ?></p>
                            <p><strong>Join Time:</strong> <?php echo e($employee->joinTime); ?></p>
                            <p><strong>Author:</strong> <?php echo e($employee->author); ?></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<!-- Add Employee Modal -->
<!-- Add Employee Modal -->
<div class="modal fade" id="addEmployeeModal" tabindex="-1" role="dialog" aria-labelledby="addEmployeeModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addEmployeeModalLabel">Add Employee</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('employees.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <!-- Form Fields -->
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="gender">Gender</label>
                        <select class="form-control" name="gender" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="birthday">Birthday</label>
                        <input type="date" class="form-control" name="birthday">
                    </div>
                    <div class="form-group">
                        <label for="nid">NID</label>
                        <input type="text" class="form-control" name="nid">
                    </div>
                    <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" name="address">
                    </div>
                    <div class="form-group">
                        <label for="photo">Photo</label>
                        <input type="file" class="form-control" name="photo">
                    </div>
                    <div class="form-group">
                        <label for="branch_id">Branch</label>
                        <select class="form-control" name="branch_id" required>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="designation">Designation</label>
                        <input type="text" class="form-control" name="designation">
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="text" class="form-control" name="phone">
                    </div>
                    <div class="form-group">
                        <label for="salary">Salary</label>
                        <input type="number" class="form-control" name="salary" step="0.01">
                    </div>
                    <div class="form-group">
                        <label for="eSalaryAcc">eSalaryAcc</label>
                        <input type="text" class="form-control" name="eSalaryAcc">
                    </div>
                    <div class="form-group">
                        <label for="payLeave">Pay Leave</label>
                        <input type="number" class="form-control" name="payLeave" value="0">
                    </div>
                    <div class="form-group">
                        <label for="npayLeave">Non-Pay Leave</label>
                        <input type="number" class="form-control" name="npayLeave" value="0">
                    </div>
                    <div class="form-group">
                        <label for="evmoSalarydate">Salary Date</label>
                        <input type="date" class="form-control" name="evmoSalarydate">
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select class="form-control" name="status">
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                            <option value="On Leave">On Leave</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="joinDate">Join Date</label>
                        <input type="date" class="form-control" name="joinDate">
                    </div>
                    <div class="form-group">
                        <label for="joinTime">Join Time</label>
                        <input type="time" class="form-control" name="joinTime">
                    </div>
                    <div class="form-group">
                        <label for="author">Author</label>
                        <input type="text" class="form-control" name="author">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web-poll\resources\views\admin\employee.blade.php ENDPATH**/ ?>