

<?php $__env->startSection('content'); ?>
<div class="row">
    <div align="left">
        <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#addBranchModal">Add branch</button>
    </div>
    <div class="container">
        <table id="plansTable" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Values</th>
                    <th>Created date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($branch->name); ?></td>
                    <td><?php echo e($branch->address); ?></td>
                    <td><?php echo e($branch->phone); ?></td>
                    <td><?php echo e($branch->total_values); ?></td>
                    <td><?php echo e($branch->updated_at); ?></td>
                    <td>
                        <button class="btn btn-sm btn-primary edit-btn" data-id="<?php echo e($branch->id); ?>" data-name="<?php echo e($branch->name); ?>" data-address="<?php echo e($branch->address); ?>" data-phone="<?php echo e($branch->phone); ?>" data-total_values="<?php echo e($branch->total_values); ?>">Edit</button>
                        <button class="btn btn-sm btn-danger delete-btn" data-id="<?php echo e($branch->id); ?>">Delete</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Branch Modal -->
<div class="modal fade" id="addBranchModal" tabindex="-1" role="dialog" aria-labelledby="addBranchModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="addBranchForm" method="POST" action="<?php echo e(route('branches.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="addBranchModalLabel">Add Branch</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" id="address" name="address" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="text" class="form-control" id="phone" name="phone" required>
                    </div>
                    <div class="form-group">
                        <label for="total_values">Values</label>
                        <input type="number" class="form-control" id="total_values" name="total_values" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Branch Modal -->
<div class="modal fade" id="editBranchModal" tabindex="-1" role="dialog" aria-labelledby="editBranchModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="editBranchForm" method="POST" action="<?php echo e(route('branches.update', ['branch' => 0])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="editBranchModalLabel">Edit Branch</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="editBranchId" name="id">
                    <div class="form-group">
                        <label for="editName">Name</label>
                        <input type="text" class="form-control" id="editName" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="editAddress">Address</label>
                        <input type="text" class="form-control" id="editAddress" name="address" required>
                    </div>
                    <div class="form-group">
                        <label for="editPhone">Phone</label>
                        <input type="text" class="form-control" id="editPhone" name="phone" required>
                    </div>
                    <div class="form-group">
                        <label for="editTotalValues">Values</label>
                        <input type="number" class="form-control" id="editTotalValues" name="total_values" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Branch Modal -->
<div class="modal fade" id="deleteBranchModal" tabindex="-1" role="dialog" aria-labelledby="deleteBranchModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="deleteBranchForm" method="POST" action="<?php echo e(route('branches.destroy', ['branch' => 0])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteBranchModalLabel">Delete Branch</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this branch?</p>
                    <input type="hidden" id="deleteBranchId" name="id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
    $('#plansTable').DataTable({
        "paging": true,
        "searching": true
    });

    // Handle edit button click
    $('.edit-btn').on('click', function() {
        var id = $(this).data('id');
        var name = $(this).data('name');
        var address = $(this).data('address');
        var phone = $(this).data('phone');
        var total_values = $(this).data('total_values');

        $('#editBranchId').val(id);
        $('#editName').val(name);
        $('#editAddress').val(address);
        $('#editPhone').val(phone);
        $('#editTotalValues').val(total_values);

        var action = $('#editBranchForm').attr('action');
        action = action.replace('/0', '/' + id);
        $('#editBranchForm').attr('action', action);

        $('#editBranchModal').modal('show');
    });

    // Handle delete button click
    $('.delete-btn').on('click', function() {
        var id = $(this).data('id');
        $('#deleteBranchId').val(id);

        var action = $('#deleteBranchForm').attr('action');
        action = action.replace('/0', '/' + id);
        $('#deleteBranchForm').attr('action', action);

        $('#deleteBranchModal').modal('show');
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web-poll\resources\views\admin\branches.blade.php ENDPATH**/ ?>