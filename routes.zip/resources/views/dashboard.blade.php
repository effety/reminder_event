@extends('layouts.app')

@section('content')
<div class="row">
<div class="col-xl-6">
    <div class="d-flex align-items-center justify-content-between">
        <div>
            @php
            $admin = auth()->user();
            $user = $admin->user;
            $activeCall = App\Models\Chat::where(function ($query) use ($user) {
                $query->where('receiver_id', $user->id)
                      ->orWhere('caller_id', $user->id);
            })
            ->whereIn('status', ['active', 'pending'])
            ->first();
            @endphp

            @if ($activeCall)
                <a id="endCallbutton" class="btn btn-sm btn-danger ml-2">{{translate('End Call')}}</a>
            @else
                <p>{{translate('No active call')}}</p>
            @endif
        </div>
        <!-- <div class="ml-2">
            <input type="text" class="form-control" id="searchByUsername" placeholder="Search By Username">
        </div> -->
    </div>
</div>

    <div class="col-xl-6">
        <div class="card card-plain">
            
            <form id="searchForm">
            <div class="d-flex" style="margin-right: 20px;">
    <div class="filter-select-box">
        <select name="country">
            <option value="">{{translate('Select Country')}}</option>
                        @foreach($countries as $country)
                            <option value="{{ $country->id }}">{{ $country->name }}</option>
                        @endforeach
        </select>
    </div>
    <div class="filter-select-box">
        <select name="language">
        <option value="">{{translate('Select Language')}}</option>
                        @foreach($languages as $language)
                            <option value="{{ $language->id }}">{{ $language->name }}</option>
                        @endforeach
        </select>
    </div>
    <div class="filter-select-box">
        <select name="age">
        <option value="">{{translate('Select Age')}}</option>
                        <option value="18-25">18-25</option>
                        <option value="26-35">26-35</option>
                        <option value="36-45">36-45</option>
                        <option value="46-55">46-55</option>
                        <option value="56-65">56-65</option>
                        <option value="66-75">66-75</option>
                        <option value="76 and more">76 and more</option>
                 </select>       
                </div>
                    <div class="filter-select-box">
                        <select name="gender">
                        <option value="">{{translate('Select Gender')}}</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="others">Others</option>
                        </select>
                    </div>
                    </div>
                    </form>
                    
        </div>
</div>
<div class="row">
<div id="bannerSlider" class="carousel slide" data-ride="carousel" style="margin-right: 50px;">
  <div class="carousel-inner">
    @foreach($sliders as $key => $slider)
    <div class="carousel-item {{ $key == 0 ? 'active' : '' }}">
      <img src="{{ asset('images/apps/'.$slider->image) }}" class="d-block w-100" alt="{{ $slider->banner_name }}" height="300px">
    </div>
    @endforeach
  </div>
  <a class="carousel-control-prev" href="#bannerSlider" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">{{translate('Previous')}}</span>
  </a>
  <a class="carousel-control-next" href="#bannerSlider" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">{{translate('Next')}}</span>
  </a>
</div>

</div>
<div id="userDetails"></div>

<div id="searchFriends" class="row"></div>
<a id="loadMore" href="#" class="d-none text-primary">{{translate('See More')}}</a>

<div class="row" id="randomUsers">
<h5 class="text-primary">{{translate('Pals')}}</h5>
@if(isset($message))
    <div class="alert alert-info">{{ $message }}</div>
    @else
    @php
    $backgroundColors = ['bg-custom1', 'bg-custom2', 'bg-custom3'];
    $colorIndex = 0;
@endphp
@foreach($randomusers as $ruser)
    @php
        // Get the current background color
        $currentColor = $backgroundColors[$colorIndex % count($backgroundColors)];
        // Define the border color based on the background color
        $borderColor = $currentColor;
    @endphp
    <div class="col-lg-2 col-md-4 col-sm-6 mt-4 mb-4">
        <div class="card shadow d-flex flex-column justify-content-between align-items-center custom-border border-{{ $borderColor }}" style="height: 200px; border-radius: 10px !important;">
            <div class="position-relative w-100 h-100" style="overflow: hidden;">
                <div class="position-absolute top-0 start-0 w-100 h-30 {{ $currentColor }}"></div>
                <div class="position-absolute bottom-0 start-0 w-100 h-70 bg-white"></div>
                <div class="position-absolute top-50 start-50 translate-middle text-center" style="z-index: 1;">
                    <img src="{{ $ruser->profile_pic ? asset('images/users/' . $ruser->profile_pic) : asset('images/users/avatar.jpg') }}" class="rounded-circle" height="70px" width="70px" style="position: relative; z-index: 2;">
                    <p class="card-title mt-2" style="position: relative; z-index: 2; white-space: nowrap;">{{$ruser->first_name}} {{$ruser->last_name}}</p>
                </div>
            </div>
            <div class="text-center mb-2">
                <a href="{{ route('match.details', ['userId' => encrypt($ruser->id)]) }}" class="btn btn-sm btn-primary">{{ translate('Invite') }}</a>
            </div>
        </div>
    </div>
    @php
        $colorIndex++;
    @endphp
@endforeach







@endif


</div>
<script>
    // Your script here
    function subscribeAlert() {
        toastr.error('Please subscribe to access this feature.');
    }
</script>
@endsection

@section('scripts')
<script>
$(document).ready(function() {
   let currentPage = 1;
    let colorIndex = 0;
    const backgroundColors = ['bg-custom1', 'bg-custom2', 'bg-custom3']; 

function loadUsers(page) {
    $('#randomUsers').hide();
    var formData = $('#searchForm').serialize() + '&page=' + page;
    $.ajax({
        url: "{{ route('search') }}",
        method: "GET",
        data: formData,
        dataType: "json",
        success: function(response) {
            if (page === 1) {
                $('#searchFriends').empty();
            }

            $.each(response.data, function(index, user) {
                let currentColor = backgroundColors[colorIndex % backgroundColors.length];
                let borderColor = currentColor;
                colorIndex++;

                let userHtml = `
                    <div class="col-lg-2 col-md-4 col-sm-6 mt-4 mb-4">
                        <div class="card shadow d-flex flex-column justify-content-between align-items-center custom-border border-${borderColor}" style="height: 200px; border-radius: 10px !important;">
                            <div class="position-relative w-100 h-100" style="overflow: hidden;">
                                <div class="position-absolute top-0 start-0 w-100 h-30 ${currentColor}"></div>
                                <div class="position-absolute bottom-0 start-0 w-100 h-70 bg-white"></div>
                                <div class="position-absolute top-50 start-50 translate-middle text-center" style="z-index: 1;">
                                    <img src="${user.profile_pic ? 'images/users/' + user.profile_pic : '{{ asset('images/users/avatar.jpg') }}'}" class="rounded-circle" height="70px" width="70px" style="position: relative; z-index: 2;">
                                    <p class="card-title mt-2" style="position: relative; z-index: 2; white-space: nowrap;">${user.first_name} ${user.last_name}</p>
                                </div>
                            </div>
                            <div class="text-center mb-2">
                            <a href="{{ route('match.details', ['userId' => encrypt($ruser->id)]) }}" class="btn btn-sm btn-primary">{{translate('Invite')}}</a>
                            </div>
                        </div>
                    </div>`;
                    
                $('#searchFriends').append(userHtml);
            });

            if (response.next_page_url) {
                $('#loadMore').removeClass('d-none');
            } else {
                $('#loadMore').addClass('d-none');
            }
        },
        error: function(xhr, status, error) {
            console.error(error);
        }
    });
}

$('#searchForm select, #searchForm input[type="date"]').change(function() {
    currentPage = 1;
    loadUsers(currentPage);
});

$('#loadMore').click(function(e) {
    e.preventDefault();
    currentPage++;
    loadUsers(currentPage);
});



    $('#searchByUsername').on('keyup', function() {
    var username = $(this).val();
    console.log(username); // Log the username for debugging

    $.ajax({
        url: '{{ route("searchByUsername") }}',
        method: 'POST',
        data: { username: username },
        dataType: 'json',
        success: function(response) {
            if (response.user) {
                var user = response.user; // Corrected variable name
                var userDetails = '<div class="col-lg-2 col-md-4 col-sm-6 mt-4 mb-4">' +
                    '<div class="card bg-transparent shadow-xl d-flex justify-content-center align-items-center" style="height: 200px;">' +
                    '<div class="overflow-hidden position-relative border-radius-xl text-center">';
                if (user.profile_pic) {
                    userDetails += '<img src="images/users/' + user.profile_pic + '" height="100px" width="100px">';
                } else {
                    userDetails += '<img src="{{ asset('images/users/avatar.jpg') }}" height="100px" width="100px">';
                }
                userDetails += '<p class="card-title mt-2">' + user.first_name + ' ' + user.last_name + '</p>';

                // Check if the logged-in user is subscribed or not
                userDetails += '<a href="{{ route('match.details', ['userId' => encrypt($ruser->id)]) }}" class="btn btn-sm btn-primary">{{translate('Invite')}}</a>';

                userDetails += '</div>' +
                    '</div>' +
                    '</div>';

                // Append the generated HTML to the userDetails div
                $('#userDetails').html(userDetails);
            } else {
                $('#userDetails').html('<p>{{translate('User not found')}}</p>');
            }
        },
        error: function(xhr, status, error) {
            console.error(error);
        }
    });
});

});
    

$('#endCallbutton').click(function(e) {
    e.preventDefault();
    $.ajax({
        url: '{{ route("reject.call") }}',
        type: 'POST',
        data: {
            _token: '{{ csrf_token() }}'
        },
        success: function(response) {
            if (response.success) {
                window.location.href = '{{ route("dashboard") }}';
            } else {
            }
        },
        error: function(xhr, status, error) {
            console.error(error);
        }
    });
        });
    </script>
    <script>
  $(document).ready(function() {
    $('#bannerSlider').carousel();
    $('#bannerSlider').carousel({
      interval: 300
    });
  });
</script>
@endsection
